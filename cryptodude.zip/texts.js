exports.texts = {
  "de-DE": {
    "translation": {
      "HINT": "{{name}} hat in den letzten 24 Stunden {{change}}% zugelegt und ist derzeit auf Platz {{rank}}."
    }
  },
  "en-US": {
  }
}